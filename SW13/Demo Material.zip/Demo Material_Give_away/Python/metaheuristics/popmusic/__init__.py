from __future__ import absolute_import
from .popmusic import Popmusic

__all__ = ['Popmusic']
__version__ = "0.0.1"
