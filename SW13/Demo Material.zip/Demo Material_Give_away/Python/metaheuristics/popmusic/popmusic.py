from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import abc
import copy
import datetime
import math
import pickle
import signal
import sys
import time


def round_figures(x, n):
    """Returns x rounded to n significant figures."""
    return round(x, int(n - math.ceil(math.log10(abs(x)))))


def time_string(seconds):
    """Returns time in seconds as a string formatted HHHH:MM:SS."""
    s = int(round(seconds))  # round to nearest second
    h, s = divmod(s, 3600)   # get hours and remainder
    m, s = divmod(s, 60)     # split remainder into minutes and seconds
    return '%4i:%02i:%02i' % (h, m, s)


class Popmusic(object):

    """Performs the POPMUSIC meta heuristic.
    """

    __metaclass__ = abc.ABCMeta

    # defaults
    sizeSubProblem = 10     # number of parts constituting a subproblem to be optimized
    updates = 100
    copy_strategy = 'deepcopy'
    user_exit = False
    save_state_on_exit = False

    # placeholders
    state = None
    parts = None
    seedPart = None
    partialState = None
    optimizedParts = None
    best_state = None
    best_energy = None
    start = None

    def __init__(self, initial_state=None, load_state=None):
        if initial_state is not None:
            self.state = self.copy_state(initial_state)
        elif load_state:
            self.load_state(load_state)
        else:
            raise ValueError('No valid values supplied for neither \
            initial_state nor load_state')

        signal.signal(signal.SIGINT, self.set_user_exit)


    def save_state(self, fname=None):
        """Saves state to pickle"""
        if not fname:
            date = datetime.datetime.now().strftime("%Y-%m-%dT%Hh%Mm%Ss")
            fname = date + "_energy_" + str(self.energy()) + ".state"
        with open(fname, "wb") as fh:
            pickle.dump(self.state, fh)


    def load_state(self, fname=None):
        """Loads state from pickle"""
        with open(fname, 'rb') as fh:
            self.state = pickle.load(fh)
        return self.copy_state(self.state)
    
    def set_state(self, state):
        self.state = self.copy_state(state)


    @abc.abstractmethod
    def initPartsOfState(self):
        """Creates the parts of the current state"""
        pass

    @abc.abstractmethod
    def initOptimizedParts(self):
        """Initializes the set of the optimized parts"""
        pass

    @abc.abstractmethod
    def setPartialState(self):
        """Create a partial state"""
        pass

    @abc.abstractmethod
    def optimizePartialState(self):
        """optimize the partial state"""
        pass
    
    @abc.abstractmethod
    def reinsertPartialState(self):
        """Reinsert partial state into state"""
        pass

    @abc.abstractmethod
    def optimizationStillOngoing(self):
        """Checks whether all parts have been optimized"""
        pass

    @abc.abstractmethod
    def addToOptimizedParts(self):
        """Add the seed part to the set of optimized parts (or similar)"""
        pass

    @abc.abstractmethod
    def removeFromOptimizedParts(self):
        """Remove the parts of the partial state from the set of optimized parts (or similar)"""
        pass

    @abc.abstractmethod
    def energy(self):
        """Calculate state's energy"""
        pass

    def set_user_exit(self, signum, frame):
        """Raises the user_exit flag, further iterations are stopped
        """
        self.user_exit = True

    def set_schedule(self, schedule):
        """Takes the output from `auto` and sets the attributes
        """
        self.sizeSubProblem = int(schedule['subsize'])

    def copy_state(self, state):
        """Returns an exact copy of the provided state
        Implemented according to self.copy_strategy, one of

        * deepcopy: use copy.deepcopy (slow but reliable)
        * slice: use list slices (faster but only works if state is list-like)
        * method: use the state's copy() method
        """
        if self.copy_strategy == 'deepcopy':
            return copy.deepcopy(state)
        elif self.copy_strategy == 'slice':
            return state[:]
        elif self.copy_strategy == 'method':
            return state.copy()
        else:
            raise RuntimeError('No implementation found for ' +
                               'the self.copy_strategy "%s"' %
                               self.copy_strategy)

    def update(self, *args, **kwargs):
        """Wrapper for internal update.

        If you override the self.update method,
        you can chose to call the self.default_update method
        from your own Popmusic.
        """
        self.default_update(*args, **kwargs)

    def default_update(self, step, E):
        """Default update, outputs to stderr.

        Prints the current state of the algorithm:
        iteration steps, energy, number of optimized parts, number of parts
        elapsed time."""

        elapsed = time.time() - self.start
        if step == 1:
            print('\n Iteration        Energy      Optimized/Parts       Elapsed   ',
                  file=sys.stderr)
            print('\r{Iter:8d}       {Energy:12.2f}    {Opt:6d}/{Parts:6d}     {Elapsed:s}            '
                  .format(Iter=step,
                          Energy=E,
                          Opt=len(self.optimizedParts),
                          Parts=len(self.parts), 
                          Elapsed=time_string(elapsed)),
                  file=sys.stderr, end="")
        else:
            print('\r{Iter:8d}       {Energy:12.2f}    {Opt:6d}/{Parts:6d}     {Elapsed:s}            '
                  .format(Iter=step,
                          Energy=E,
                          Opt=len(self.optimizedParts),
                          Parts=len(self.parts), 
                          Elapsed=time_string(elapsed)),
                  file=sys.stderr, end="")
        sys.stderr.flush()
        


    def popmusic(self):
        """Minimizes the energy of a system by POPMUSIC meta heuristic.

        Parameters
        state: an initial arrangement of the system

        Returns
        (state, energy): the best state and energy found.
        """
        step = 0
        self.start = time.time()

        # Setup the parts of the initial state and the set of optimized parts
        self.initPartsOfState()
        self.initOptimizedParts()
        
        # Note initial state
        E = self.energy()
        prevEnergy = E

        self.best_state = self.copy_state(self.state)
        self.best_energy = E
        
        # Optimization loop
        while self.optimizationStillOngoing() and not self.user_exit:
            step += 1
            
            self.setPartialState()
            dE = self.optimizePartialState()

            if dE >= 0.0:       # Partial state has not been improved
                # Restore previous state
                # Update the set of optimized parts
                self.addToOptimizedParts()
            else:
                # Accept new state and compare to best state
                if dE is None:
                    E = self.energy()
                    dE = E - prevEnergy
                else:
                    E += dE
                prevEnergy = E
                self.reinsertPartialState()
                self.removeFromOptimizedParts()

                if E < self.best_energy:
                    self.best_state = self.copy_state(self.state)
                    self.best_energy = E

            self.update(step, E)

        self.state = self.copy_state(self.best_state)
        if self.save_state_on_exit:
            self.save_state()

        # Return best state and energy
        return self.best_state, self.best_energy
