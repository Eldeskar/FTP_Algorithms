# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import abc
import copy
import datetime
import math
import pickle
import signal
import sys
import time

import logging
import numpy as np


def round_figures(x, n):
    """Returns x rounded to n significant figures."""
    return round(x, int(n - math.ceil(math.log10(abs(x)))))


def time_string(seconds):
    """Returns time in seconds as a string formatted HHHH:MM:SS."""
    s = int(round(seconds))  # round to nearest second
    h, s = divmod(s, 3600)   # get hours and remainder
    m, s = divmod(s, 60)     # split remainder into minutes and seconds
    return '%4i:%02i:%02i' % (h, m, s)


class AntColonyOptimization(object):

    """Performs the Ant Colony Optimization meta heuristic.
    """

    __metaclass__ = abc.ABCMeta

    # defaults
    updates = 100
    copy_strategy = 'deepcopy'
    user_exit = False
    save_state_on_exit = False

    # placeholders
    state = None
    best_state = None
    best_energy = None
    start = None

    """
    Ant colony optimization algorithm for combinatorial problems related to
    graphs.

    Parameters:
        m = number of ants
        k_max = number of iterations
        alpha = pheromone importance
        beta = distance importance
        rho = pheromone evaporation rate
        Q = pheromone deposit
    """
    """ 
    Structure of self.state:
        self.state.distance_matrix: distances between nodes (nxn-array numpy)
        self.state.tau:             pheromone matrix (nxn-array numpy)
        self.state.eta:             inverse distances matrix (nxn-array numpy)
        self.state.R:               pheromone reinforcement matrix (nxn-array numpy)
 """
    
    def __init__(self, initial_state=None, load_state=None, **kwargs):
        if initial_state is not None:
            self.state = self.copy_state(initial_state)
        elif load_state:
            self.load_state(load_state)
        else:
            raise ValueError('No valid values supplied for neither \
            initial_state nor load_state')

        signal.signal(signal.SIGINT, self.set_user_exit)
        
        
        self.m = kwargs.get("m", 200)
        self.k_max = kwargs.get("k_max", 150)
        self.alpha = kwargs.get("alpha", 1)
        self.beta = kwargs.get("beta", 1.8)
        self.rho = kwargs.get("rho", 0.60)
        self.Q = kwargs.get("Q", 1)


    def ant_colony_optimization(self):
        """
        Ant colony optimization algorithm
        Constructs solutions of minimized energy of a problem instance 
        represented in self.state by Ant Colony Optimization meta heuristic.

        Parameters
        self.state: an initial arrangement of the system

        Returns
        (best_solution, best_energy): the best state and energy found.
        """
        self.start = time.time()
        step = 0

        best_solution = self.init_best_solution()
        best_energy = float("inf")
        
        while step < self.k_max and not self.user_exit:
            step += 1
            
            self.edge_attractiveness()
            
            self.state.init_R()
            for _ in range(self.m):
                best_solution, best_energy = self.ant_walk(best_solution, best_energy)
 
            self.state.tau *= (1-self.rho)
            self.state.tau += self.state.R
            
            self.update(step, best_energy)
            self.special_action()   # hook for graphics update etc.

            
        if self.save_state_on_exit:
            self.save_state()
            
        return best_solution, best_energy


    def edge_attractiveness(self):
        """
        Calculate edge attractiveness
        tau = pheromone
        eta = inverse distances
        alpha = pheromone importance
        beta = distance importance
        """
        self.state.A = (self.state.tau ** self.alpha) * (self.state.eta ** self.beta)
        self.state.A = self.state.A - np.diag(np.diag(self.state.A))


    @abc.abstractmethod
    def ant_walk(self, best_solution, best_energy):
        """ generate a solution, compute its energy and update reinforcement
            matrix R"""
        pass

    
    @abc.abstractmethod
    def init_best_solution(self):
        pass


    @abc.abstractmethod
    def energy(self):
        """Calculate state's energy"""
        pass


    @abc.abstractmethod
    def special_action(self):
        """ generate a solution, compute its energy and update reinforcement
            matrix R"""
        pass

    
    def save_state(self, fname=None):
        """Saves state to pickle"""
        if not fname:
            date = datetime.datetime.now().strftime("%Y-%m-%dT%Hh%Mm%Ss")
            fname = date + "_energy_" + str(self.energy()) + ".state"
        with open(fname, "wb") as fh:
            pickle.dump(self.state, fh)


    def load_state(self, fname=None):
        """Loads state from pickle"""
        with open(fname, 'rb') as fh:
            self.state = pickle.load(fh)
        return self.copy_state(self.state)

    
    def set_state(self, state):
        self.state = self.copy_state(state)


    def set_user_exit(self, signum, frame):
        """Raises the user_exit flag, further iterations are stopped
        """
        self.user_exit = True


    def set_schedule(self, schedule):
        """Takes the output from `auto` and sets the attributes
        """
        self.alpha = float(schedule['alpha'])
        self.beta = float(schedule['beta'])
        self.rho = float(schedule['rho'])
        self.Q = float(schedule['Q'])
        self.m = int(schedule['ants'])
        self.k_max = int(schedule['steps'])
        return


    def copy_state(self, state):
        """Returns an exact copy of the provided state
        Implemented according to self.copy_strategy, one of

        * deepcopy: use copy.deepcopy (slow but reliable)
        * slice: use list slices (faster but only works if state is list-like)
        * method: use the state's copy() method
        """
        if self.copy_strategy == 'deepcopy':
            return copy.deepcopy(state)
        elif self.copy_strategy == 'slice':
            return state[:]
        elif self.copy_strategy == 'method':
            return state.copy()
        else:
            raise RuntimeError('No implementation found for ' +
                               'the self.copy_strategy "%s"' %
                               self.copy_strategy)


    def update(self, *args, **kwargs):
        """Wrapper for internal update.

        If you override the self.update method,
        you can chose to call the self.default_update method.
        """
        self.default_update(*args, **kwargs)


    def default_update(self, step, E):
        """Default update, outputs to stderr.
        Prints the current state of the algorithm:
        iteration steps, energy, number of optimized parts, number of parts
        elapsed time."""
        elapsed = time.time() - self.start
        if step == 1:
            print('\n Iteration        Energy        Elapsed   ',
                  file=sys.stderr)
            print('\r{Iter:8d}       {Energy:12.2f}    {Elapsed:s}            '
                  .format(Iter=step,
                          Energy=E,
                          Elapsed=time_string(elapsed)),
                  file=sys.stderr, end="")
        else:
            print('\r{Iter:8d}       {Energy:12.2f}    {Elapsed:s}            '
                  .format(Iter=step,
                          Energy=E,
                          Elapsed=time_string(elapsed)),
                  file=sys.stderr, end="")
        sys.stderr.flush()
