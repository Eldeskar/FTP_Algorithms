# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

greedy random insertion heuristic for generating TSP solution.

@author: beer
"""

import random
import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from helpers import Helpers


class TspGreedyInsertionRandom:

    def generate(instance):
        points = instance.getPoints()
        #points.sort(key=lambda x: x.getId())
        random.shuffle(points)

        nextIndices = [int(0)]*len(points)  # array with the indices of the next nodes
        nextIndices[0] = 1                  # initial partial tour is 0 -> 1 -> 0
		
        TspGreedyInsertionRandom.findBestInsertPosition(points, nextIndices)
        solution = TspGreedyInsertionRandom.buildTourFromIndices(points, nextIndices)

        return solution


    def iterate(solution):
		
        new_solution = solution[:]
        
        while len(solution) > 0:
            point = solution.pop(random.randrange(len(solution)))
            k = TspGreedyInsertionRandom.find_point_index(new_solution, point)

            # gain of removal: + means shorter distance, - means longer distance
            gain_of_removal  = Helpers.euclideanDistance2DPoints(point, new_solution[k-1])
            gain_of_removal += Helpers.euclideanDistance2DPoints(point, new_solution[(k+1)%len(new_solution)])
            gain_of_removal -= Helpers.euclideanDistance2DPoints(new_solution[k-1], new_solution[(k+1)%len(new_solution)])

            del new_solution[k]

            best_total_gain = -sys.float_info.max
            best_insert_position = k
            for j in range(len(new_solution)):
                total_gain = gain_of_removal
                
                total_gain += Helpers.euclideanDistance2DPoints(new_solution[j-1], new_solution[j])
                total_gain -= Helpers.euclideanDistance2DPoints(point, new_solution[j-1])
                total_gain -= Helpers.euclideanDistance2DPoints(point, new_solution[j])
                
                if total_gain > best_total_gain:
                    best_total_gain = total_gain
                    best_insert_position = j
                    
            new_solution.insert(best_insert_position, point)
                
        return new_solution


    def find_point_index(solution, point):
        for i, p in enumerate(solution):
            if p.id == point.id:
                return i
        return "No matching point found"


    def	findBestInsertPosition(points, nextIndices):
        # find the best position to insert for each remaining point
        for i in range(2, len(points)):
            lowestDistanceIncrease = sys.float_info.max
            lowestDistanceIncreaseIdx = int(-1)
			
            for j in range(i):
                # compute increase of cost of tour if point i is inserted in place j
                distanceIncrease = Helpers.euclideanDistance2DPoints(points[j], points[i]) + Helpers.euclideanDistance2DPoints(points[i], points[nextIndices[j]]) - Helpers.euclideanDistance2DPoints(points[j], points[nextIndices[j]])
                if distanceIncrease < lowestDistanceIncrease:
                    lowestDistanceIncrease = distanceIncrease
                    lowestDistanceIncreaseIdx = j
			
            nextIndices[i] = nextIndices[lowestDistanceIncreaseIdx]
            nextIndices[lowestDistanceIncreaseIdx] = i

	
    def buildTourFromIndices(points, nextIndices):
        # walk along next indices to build solution
        solution = []
        j = int(0)
        for i in range(len(points)):
            solution.append(points[j])
            j = nextIndices[j]
            
        return solution
