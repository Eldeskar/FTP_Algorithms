# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

nearest neighbor heuristic for generating TSP solution.

@author: beer
"""

import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from helpers import Helpers


class TspNearestNeighbor:

    def generate(instance, startIndex):
        workingPoints = instance.clonePointList()

        solution = []
        currentPoint = workingPoints.pop(startIndex)
        solution.append(currentPoint)

        while len(workingPoints) != 0:
            nearestPointIdx = 0
            shortestDistance = sys.float_info.max

            for i in range(len(workingPoints)):
                tempDistance = Helpers.euclideanDistance2DPoints(currentPoint, workingPoints[i])

                if tempDistance < shortestDistance:
                    nearestPointIdx = i
                    shortestDistance = tempDistance

            currentPoint = workingPoints.pop(nearestPointIdx)
            solution.append(currentPoint)

        return solution
