# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with popmusic metaheuristic.

@author: beer
"""

import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))

from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_greedy_insertion_random import TspGreedyInsertionRandom
from tsp_popmusic_exhaustive import TspPopmusic


if __name__ == '__main__':
    
    instanceName = 'tsp225'

    solutionName = instanceName + '_popmusic'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension    
    
    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating an initial solution...')

    solution = TspGreedyInsertionRandom.generate(instance)
    distance = Helpers.euclideanDistance2DList(solution)

    print('Initial solution for ' + instanceName + ' has length: ' + str(distance))
    print('Refining solution with the popmusic metaheuristic...')
    print('', flush=True)

    tsp = TspPopmusic(solution)

    tsp.set_schedule({'subsize': 10})

    solution, distance = tsp.findSolution()

    for i in range(len(solution)):          # rotate id = 0 to beginning
        if solution[i].getId() == 0:
            break
    solution = solution[i:] + solution[:i]  

    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
