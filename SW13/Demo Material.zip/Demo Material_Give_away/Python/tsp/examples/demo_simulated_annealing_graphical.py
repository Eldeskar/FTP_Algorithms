1# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with simulated annealing metaheuristic
and with dynamical graphical depictions during computation

@author: beer
"""

import random
import sys
import os

import matplotlib.pyplot as plt
import numpy as np

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + '..' + os.path.sep + 'metaheuristics' + os.path.sep + 'simanneal' + os.path.sep))
from anneal import Annealer


class TravellingSalesmanProblem(Annealer):

    # pass extra data (if any) into the constructor
    def __init__(self, state):
        self.set_up_graphics(state)
        super(TravellingSalesmanProblem, self).__init__(state)  # important!


    def move(self):
        NUM_POSSIBLE_MOVES = 4
        k = random.randint(1, NUM_POSSIBLE_MOVES) 
        if k == 1:
            return self.swap_cities()
        elif k == 2:
            return self.move_one_city()
        elif k== 3:
            return self.reverse_subtrail()
        else:
            return self.reverse_short_subtrail()


    def swap_cities(self):
        # choose two different cities in the route
        while True:
            a = random.randint(0, len(self.state) - 1)
            b = random.randint(0, len(self.state) - 1)
            if a != b:
                break

        # enforc a < b, except for special case    
        if a>b:
            a, b = b, a
        if a==0 and b==len(self.state)-1:
            a, b = b, a

        # compute delta energy
        dE = 0.
        dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[(b+1)%len(self.state)])
        dE += Helpers.euclideanDistance2DPoints(self.state[b], self.state[a-1])
        dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[a-1])
        dE -= Helpers.euclideanDistance2DPoints(self.state[b], self.state[(b+1)%len(self.state)])
        if (a+1)%len(self.state) != b:
            dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[b-1])
            dE += Helpers.euclideanDistance2DPoints(self.state[b], self.state[(a+1)%len(self.state)])
            dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[(a+1)%len(self.state)])
            dE -= Helpers.euclideanDistance2DPoints(self.state[b], self.state[b-1])
            
        # swap cities
        self.state[a], self.state[b] = self.state[b], self.state[a]
        
        return dE
    
    
    def move_one_city(self):
        # choose two different cities in the route
        while True:
            a = random.randint(0, len(self.state) - 1)
            b = random.randint(0, len(self.state) - 1)
            x = abs(a-b)
            if x > 1 and x < len(self.state)-1:    # a and b schould not be neighbours
                break

        # compute delta energy
        dE = 0.
        dE += Helpers.euclideanDistance2DPoints(self.state[a-1], self.state[(a+1)%len(self.state)])
        dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[a-1])
        dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[(a+1)%len(self.state)])

        dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[b])
        dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[b-1])
        dE -= Helpers.euclideanDistance2DPoints(self.state[b], self.state[b-1])
            
        # insert city a before city b
        point = self.state.pop(a)
        if a < b:
            self.state.insert(b-1, point)
        else:
            self.state.insert(b, point)
        
        return dE
    
    
    def reverse_subtrail(self):
        # choose two different cities in the route
        while True:
            a = random.randint(0, len(self.state) - 1)
            b = random.randint(0, len(self.state) - 1)
            if a != b:
                break
            
        # enforc a < b, except for special case    
        if a>b:
            a, b = b, a
        if a==0 and b==len(self.state)-1:
            a, b = b, a

        # compute delta energy
        dE = 0.
        dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[(b+1)%len(self.state)])
        dE += Helpers.euclideanDistance2DPoints(self.state[b], self.state[(a-1)%len(self.state)])
        dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[(a-1)%len(self.state)])
        dE -= Helpers.euclideanDistance2DPoints(self.state[b], self.state[(b+1)%len(self.state)])

        # reverse subtrail from city a to city b
        if b==0 and a==len(self.state)-1:
            self.state[a], self.state[b] = self.state[b], self.state[a]
        elif a==0:
            self.state[a:b+1] = self.state[b::-1]
        elif b==len(self.state)-1:
            self.state[a:] = self.state[b:a-1:-1]
        else:
            self.state[a:b+1] = self.state[b:a-1:-1]
            
        return dE
    

    def reverse_short_subtrail(self):
        MAX_SUBTRAIL_LEN_QUOTE = 1./1000
        MIN_SUBTRAIL_LEN = 5
        max_subtrail_len = int(round(MAX_SUBTRAIL_LEN_QUOTE*len(self.state)))
        max_subtrail_len = max(max_subtrail_len, MIN_SUBTRAIL_LEN)
        # choose two different cities in the route
        while True:
            a = random.randint(0, len(self.state) - 1)
            b = random.randint(1, max_subtrail_len)
            if a+b < len(self.state)-1:
                b = a+b
                break
            elif a-b >= 0:
                b = a-b
                break
            else:
                continue
            
        # enforc a < b, except for special case    
        if a>b:
            a, b = b, a
        if a==0 and b==len(self.state)-1:
            a, b = b, a

        # compute delta energy
        dE = 0.
        dE += Helpers.euclideanDistance2DPoints(self.state[a], self.state[(b+1)%len(self.state)])
        dE += Helpers.euclideanDistance2DPoints(self.state[b], self.state[(a-1)%len(self.state)])
        dE -= Helpers.euclideanDistance2DPoints(self.state[a], self.state[(a-1)%len(self.state)])
        dE -= Helpers.euclideanDistance2DPoints(self.state[b], self.state[(b+1)%len(self.state)])

        # reverse subtrail from city a to city b
        if b==0 and a==len(self.state)-1:
            self.state[a], self.state[b] = self.state[b], self.state[a]
        elif a==0:
            self.state[a:b+1] = self.state[b::-1]
        elif b==len(self.state)-1:
            self.state[a:] = self.state[b:a-1:-1]
        else:
            self.state[a:b+1] = self.state[b:a-1:-1]
            
        return dE
    

    def special_action(self, step, T):
        # update first graphics
        x = [self.state[i].getX() for i in range(len(self.state))]
        x.append(self.state[0].getX())
        y = [self.state[i].getY() for i in range(len(self.state))]
        y.append(self.state[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        
        # update second graphics
        self.ax2.set_xlim([0, self.steps])
        self.ax2.set_ylim([self.Tmin, self.Tmax])
        x = self.line2.get_xdata()
        x = np.append(x, step)
        y = self.line2.get_ydata()
        y = np.append(y, T)
        self.line2.set_xdata(x)
        self.line2.set_ydata(y)
        self.figure2.canvas.draw()
        self.figure2.canvas.flush_events()
        
        plt.pause(0.001)
        return 0
 
    
    def set_up_graphics(self, state):
        # first graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [state[i].getX() for i in range(len(state))]
        y = [state[i].getY() for i in range(len(state))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')

        # second graphics for temperature vs. step
        self.figure2, self.ax2 = plt.subplots()
        self.line2, = self.ax2.plot([], [], 'b')
        self.ax2.grid()

        plt.pause(0.001)
        plt.show()


    def energy(self):
        """Calculates the length of the route."""
        e = 0.
        for i in range(len(self.state)):
            e += Helpers.euclideanDistance2DPoints(self.state[i-1], self.state[i])
        return e


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_simulated_annealing'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions';

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension

    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a random initial solution...')

    random.shuffle(solution)
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Initial solution for ' + instanceName + ' has length: ' + str(distance))
    print('Refining solution with the simulated annealing metaheuristic...')
    print('', flush=True)

    plt.ion()   # interactive graphics mode on

    tsp = TravellingSalesmanProblem(solution)

    # since our state is just a list, slice is the fastest way to copy
    tsp.copy_strategy = "slice"
    #tsp.set_schedule(tsp.auto(minutes=1.5))
    tsp.set_schedule({'tmax': 4000., 'tmin': 50., 'steps': 10000, 'updates': 200})
    tsp.set_schedule({'tmax': 4000., 'tmin': 50., 'steps': 400000, 'updates': 2000})

    solution, distance = tsp.anneal()

    plt.ioff()   # interactive graphics mode off

    for i in range(len(solution)):
        if solution[i].getId() == 0:
            break
    solution = solution[i:] + solution[:i]  # rotate id = 0 to beginning

    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')
