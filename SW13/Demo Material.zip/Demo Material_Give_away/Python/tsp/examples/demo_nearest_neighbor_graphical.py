# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with the nearest neighbor heuristic.

@author: beer
"""

import sys
import os
import random

import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers



class TspNearestNeighbor(object):

    # pass extra data (if any) into the constructor
    def __init__(self, instance):
        self.instance = instance
        self.set_up_graphics()

    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [self.instance.getPoints()[i].getX() for i in range(len(self.instance.getPoints()))]
        y = [self.instance.getPoints()[i].getY() for i in range(len(self.instance.getPoints()))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()

        plt.pause(0.001)
        plt.show()
        
    def generate(self, startIndex):
        workingPoints = self.instance.clonePointList()
        solution = []
        currentPoint = workingPoints.pop(startIndex)
        solution.append(currentPoint)

        MAX_GRAPHS = len(workingPoints)
        NUM_POINTS_PER_GRAPH = max(1, len(workingPoints)//MAX_GRAPHS)    

        while len(workingPoints) != 0:
            nearestPointIdx = 0
            shortestDistance = sys.float_info.max

            for i in range(len(workingPoints)):
                tempDistance = Helpers.euclideanDistance2DPoints(currentPoint, workingPoints[i])

                if tempDistance < shortestDistance:
                    nearestPointIdx = i
                    shortestDistance = tempDistance

            # updategraphics
            if len(workingPoints) % NUM_POINTS_PER_GRAPH == 0:
                x = [solution[i].getX() for i in range(len(solution))]
                x.append(solution[0].getX())
                y = [solution[i].getY() for i in range(len(solution))]
                y.append(solution[0].getY())
                self.line1.set_xdata(x)
                self.line1.set_ydata(y)
                self.figure1.canvas.draw()
                self.figure1.canvas.flush_events()
                plt.pause(0.001)

            currentPoint = workingPoints.pop(nearestPointIdx)
            solution.append(currentPoint)

        # final graphics
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(solution[0].getX())
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(solution[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        plt.pause(0.01)

        # interactive graphics mode off
        plt.ioff()

        return solution



if __name__ == '__main__':
    
    instanceName = 'reseau_suisse'
    
    solutionName = instanceName + '_nearest_neighbor'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution with the nearest neighbor heuristic...')

    tsp = TspNearestNeighbor(instance)
    startPoint = random.randrange(len(solution))
    solution = tsp.generate(startPoint)
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
