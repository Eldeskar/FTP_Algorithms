# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with popmusic metaheuristic.

@author: beer
"""

import sys
import os
import random
import itertools
import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + '..' + os.path.sep + 'metaheuristics' + os.path.sep + 'popmusic' + os.path.sep))
from popmusic import Popmusic

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_greedy_insertion_random import TspGreedyInsertionRandom
from tsp_nearest_neighbor import TspNearestNeighbor


class TspPopmusic(Popmusic):

    # pass extra data (if any) into the constructor
    def __init__(self, state):
        self.set_up_graphics(state)
        super(TspPopmusic, self).__init__(state)  # important!


    def initPartsOfState(self):
        """Creates the parts of the current state"""
        self.parts = self.copy_state(self.state)    # parts are cities of the current solution
        return

    
    def initOptimizedParts(self):
        """Creates the parts of the current state"""
        self.optimizedParts = []                    # start with an empty list
        return


    def setPartialState(self):
        """Create a partial state"""
        # choose seed part
        notOptimizedParts = list(set(self.parts) - set(self.optimizedParts))
        self.seedPart = notOptimizedParts[random.randint(0, len(notOptimizedParts) - 1)]
        # get position of seed part in state
        for k in range(len(self.state)):
            if self.state[k].getId() == self.seedPart.getId():
                break
        
        # build partial state
        self.partialState = []
        for i in range(self.sizeSubProblem):
            self.partialState.append(self.state[(k - self.sizeSubProblem//2 + i)%len(self.state)])
            
        return


    def optimizePartialState(self):
        """optimize the partial state"""
        #Do exhaustive search on the inner points of the partial state
        prevE = 0.0
        for i in range(len(self.partialState)-1):
            prevE += Helpers.euclideanDistance2DPoints(self.partialState[i], self.partialState[i+1])
            
        bestE = prevE
        bestPartialState = self.partialState[:]
        currentPartialState = self.partialState[:]

        permutations = itertools.permutations(self.partialState[1:-1])
        for permutation in permutations:
            currentPartialState[1:-1] = list(permutation)
  
            currentE = 0.0
            for i in range(len(currentPartialState)-1):
                currentE += Helpers.euclideanDistance2DPoints(currentPartialState[i], currentPartialState[i+1])

            if currentE < bestE:
                bestPartialState = currentPartialState[:]
                bestE = currentE
        
        self.partialState = bestPartialState[:]

        return bestE - prevE

    
    def reinsertPartialState(self):
        """Reinsert partial state into state"""
        # get position of first part of partial state in state
        for k in range(len(self.state)):
            if self.state[k].getId() == self.partialState[0].getId():
                break

        # update first graphics
        x = [self.state[i%len(self.state)].getX() for i in range(k, k+self.sizeSubProblem)]
        y = [self.state[i%len(self.state)].getY() for i in range(k, k+self.sizeSubProblem)]
        #self.ax1.plot(x, y, 'w', linewidth=2.5)    # redrawn lines completely disappear
        self.ax1.plot(x, y, 'w')                    # redrawn lines are still visible

        x = [self.partialState[i].getX() for i in range(self.sizeSubProblem)]
        y = [self.partialState[i].getY() for i in range(self.sizeSubProblem)]
        self.ax1.plot(x, y, 'b')
        self.ax1.plot(x, y, 'b*')   # redraw points

        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        #self.line1, = self.ax1.plot([], [], 'r')
        #self.figure1.canvas.flush_events()
        plt.pause(0.001)
        plt.show()

        
        # reinsert parts of partial state
        for i in range(1, self.sizeSubProblem-1):
            self.state[(k+i)%len(self.state)] = self.partialState[i]
        
        return


    def optimizationStillOngoing(self):
        """Checks whether all parts have been optimized"""
        if len(self.optimizedParts) < len(self.state):
            return True
        else:
            return False


    def addToOptimizedParts(self):
        """Add the seed part to the set of optimized parts (or similar)"""
        found = False
        for part in self.optimizedParts:
            if part.getId() == self.seedPart.getId():
                found = True
                break
        if not found:
            self.optimizedParts.append(self.seedPart)
        return


    def removeFromOptimizedParts(self):
        """Remove the parts of the partial state from the set of optimized parts (or similar)"""
        for part in self.partialState:
            for k in range(len(self.optimizedParts)):
                if part.getId() == self.optimizedParts[k].getId():
                    self.optimizedParts.pop(k)
                    break
        #self.optimizedParts = []
        return


    def energy(self):
        """Calculates the length of the route."""
        e = 0.
        for i in range(len(self.state)):
            e += Helpers.euclideanDistance2DPoints(self.state[i-1], self.state[i])
        return e


    def set_up_graphics(self, state):
        plt.ion()

        # first graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [state[i].getX() for i in range(len(state))]
        y = [state[i].getY() for i in range(len(state))]
        self.ax1.plot(x, y, 'b*')
        self.line1, = self.ax1.plot([], [], 'r')

        x = [state[i].getX() for i in range(len(state))]
        x.append(state[0].getX())
        y = [state[i].getY() for i in range(len(state))]
        y.append(state[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()

        plt.pause(0.001)
        plt.show()


    def findSolution(self):
        # since our state is just a list, slice is the fastest way to copy
        self.copy_strategy = "slice"
        solution, distance = self.popmusic()
        return solution, distance
    


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_popmusic'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension    

    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating an initial solution...')

    solution = TspGreedyInsertionRandom.generate(instance)
    #solution = TspNearestNeighbor.generate(instance, 100)
    #random.shuffle(solution)
    distance = Helpers.euclideanDistance2DList(solution)

    print('Initial solution for ' + instanceName + ' has length: ' + str(distance))
    print('Refining solution with the popmusic metaheuristic...')
    print('', flush=True)

    tsp = TspPopmusic(solution)

    tsp.set_schedule({'subsize': 10})

    solution, distance = tsp.findSolution()

    for i in range(len(solution)):          # rotate id = 0 to beginning
        if solution[i].getId() == 0:
            break
    solution = solution[i:] + solution[:i]  

    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
