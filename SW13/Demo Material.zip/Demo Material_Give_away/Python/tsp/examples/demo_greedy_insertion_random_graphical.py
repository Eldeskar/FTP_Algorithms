# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with the greedy random insertion heuristic.

@author: beer
"""

import sys
import os
import random

import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers


class TspGreedyInsertionRandom(object):

    # pass extra data (if any) into the constructor
    def __init__(self, instance):
        self.instance = instance
        self.set_up_graphics()

    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [self.instance.getPoints()[i].getX() for i in range(len(self.instance.getPoints()))]
        y = [self.instance.getPoints()[i].getY() for i in range(len(self.instance.getPoints()))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()

        plt.pause(0.001)
        plt.show()

    def generate(self):
        points = self.instance.getPoints()
        #points.sort(key=lambda x: x.getId())
        random.shuffle(points)

        nextIndices = [int(0)]*len(points)  # array with the indices of the next nodes
        nextIndices[0] = 1                  # initial partial tour is 0 -> 1 -> 0
		
        self.findBestInsertPosition(points, nextIndices)
        solution = TspGreedyInsertionRandom.buildTourFromIndices(points, nextIndices)

        return solution


    def	findBestInsertPosition(self, points, nextIndices):
        MAX_GRAPHS = len(points)
        NUM_POINTS_PER_GRAPH = max(1, len(points)//MAX_GRAPHS)    

        # initial graphics
        solution = TspGreedyInsertionRandom.buildPartialTourFromIndices(points, nextIndices)
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(solution[0].getX())
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(solution[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        plt.pause(0.5)
        
        # find the best position to insert for each remaining point
        for i in range(2, len(points)):
            lowestDistanceIncrease = sys.float_info.max
            lowestDistanceIncreaseIdx = int(-1)
			
            for j in range(i):
                # compute increase of cost of tour if point i is inserted in place j
                distanceIncrease = Helpers.euclideanDistance2DPoints(points[j], points[i]) + Helpers.euclideanDistance2DPoints(points[i], points[nextIndices[j]]) - Helpers.euclideanDistance2DPoints(points[j], points[nextIndices[j]])
                if distanceIncrease < lowestDistanceIncrease:
                    lowestDistanceIncrease = distanceIncrease
                    lowestDistanceIncreaseIdx = j
			
            nextIndices[i] = nextIndices[lowestDistanceIncreaseIdx]
            nextIndices[lowestDistanceIncreaseIdx] = i

            # update graphics
            if (i-2) % NUM_POINTS_PER_GRAPH == 0:
                solution = TspGreedyInsertionRandom.buildPartialTourFromIndices(points, nextIndices)
                x = [solution[i].getX() for i in range(len(solution))]
                x.append(solution[0].getX())
                y = [solution[i].getY() for i in range(len(solution))]
                y.append(solution[0].getY())
                self.line1.set_xdata(x)
                self.line1.set_ydata(y)
                self.figure1.canvas.draw()
                self.figure1.canvas.flush_events()
                plt.pause(0.001)
        
        # final graphics
        solution = TspGreedyInsertionRandom.buildPartialTourFromIndices(points, nextIndices)
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(solution[0].getX())
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(solution[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        plt.pause(0.01)

        # interactive graphics mode off
        plt.ioff()

        

	
    def buildPartialTourFromIndices(points, nextIndices):
        # walk along next indices to build partial solution
        solution = []
        j = int(0)
        for i in range(len(points)):
            solution.append(points[j])
            j = nextIndices[j]
            if j == 0:
                solution.append(points[j])
                break
            
        return solution


    def buildTourFromIndices(points, nextIndices):
        # walk along next indices to build solution
        solution = []
        j = int(0)
        for i in range(len(points)):
            solution.append(points[j])
            j = nextIndices[j]
            
        return solution


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_greedy_insertion_random'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution with the greedy random insertion heuristic...')

    tsp = TspGreedyInsertionRandom(instance)
    solution = tsp.generate()
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
