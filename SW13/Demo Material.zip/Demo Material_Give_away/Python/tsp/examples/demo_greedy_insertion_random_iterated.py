# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with the greedy random insertion heuristic.

@author: beer
"""

import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_greedy_insertion_random import TspGreedyInsertionRandom


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_greedy_insertion_random_iterated'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution with the greedy random insertion heuristic...')

    solution = TspGreedyInsertionRandom.generate(instance)
    distance = Helpers.euclideanDistance2DList(solution)
            
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    NUMBER_OF_ITERATIONS = 5

    for k in range(NUMBER_OF_ITERATIONS):        
        print('rerunning best insertion on previous solution again...')
    
        solution = TspGreedyInsertionRandom.iterate(solution)
        distance = Helpers.euclideanDistance2DList(solution)
            
        print('Solution for ' + instanceName + ' has length: ' + str(distance))
        print('')
    
    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
