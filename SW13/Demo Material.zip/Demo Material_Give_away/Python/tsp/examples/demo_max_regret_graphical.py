# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with the maximum regret heuristic.

@author: beer
"""

import sys
import os
import random

import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from point import Point
from instance import Instance
from helpers import Helpers


class TspMaxRegret(object):

    # pass extra data (if any) into the constructor
    def __init__(self, instance):
        self.instance = instance
        self.set_up_graphics()

    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [self.instance.getPoints()[i].getX() for i in range(len(self.instance.getPoints()))]
        y = [self.instance.getPoints()[i].getY() for i in range(len(self.instance.getPoints()))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()

        plt.pause(0.001)
        plt.show()


    def generate(self, startIndex):
        workingPoints = self.instance.clonePointList()
        solution = []
        currentPoint = workingPoints.pop(startIndex)
        solution.append(currentPoint)

        MAX_GRAPHS = len(workingPoints)
        NUM_POINTS_PER_GRAPH = max(1, len(workingPoints)//MAX_GRAPHS)    

        while len(workingPoints) != 0:

            # find distance of nearest point
            shortestDistance = sys.float_info.max
            for i in range(len(workingPoints)):
                tempDistance = Helpers.euclideanDistance2DPoints(currentPoint, workingPoints[i])

                if tempDistance < shortestDistance:
                    shortestDistance = tempDistance
            
            # find sum of length of the 2 shortest stems of every working point
            # find sum of length of path from current point plus shortest stem for every working point
            stemLengths = []
            pathPlusStemLengths = []
            for i in range(len(workingPoints)):
                shortestDistancesPoint = [sys.float_info.max, sys.float_info.max]
                pathPlusStem = sys.float_info.max

                for j in range(len(workingPoints)):
                    if i==j:
                        continue

                    tempDistance = Helpers.euclideanDistance2DPoints(workingPoints[i], workingPoints[j])

                    if tempDistance <= shortestDistancesPoint[0]:
                        shortestDistancesPoint[1] = shortestDistancesPoint[0]
                        shortestDistancesPoint[0] = tempDistance
                    elif tempDistance < shortestDistancesPoint[1]:
                        shortestDistancesPoint[1] = tempDistance

                    if tempDistance < pathPlusStem:
                        pathPlusStem = tempDistance
                        
                        
                stemLengths.append(sum(shortestDistancesPoint))
                pathPlusStemLengths.append(pathPlusStem + Helpers.euclideanDistance2DPoints(workingPoints[i], currentPoint))

            # compute regret values
            regrets = [stemLengths[i] - pathPlusStemLengths[i] for i in range(len(workingPoints))]
              
            # find max regret point
            maxRegretIdx = regrets.index(max(regrets))

            # updategraphics
            if len(workingPoints) % NUM_POINTS_PER_GRAPH == 0:
                x = [solution[i].getX() for i in range(len(solution))]
                x.append(solution[0].getX())
                y = [solution[i].getY() for i in range(len(solution))]
                y.append(solution[0].getY())
                self.line1.set_xdata(x)
                self.line1.set_ydata(y)
                self.figure1.canvas.draw()
                self.figure1.canvas.flush_events()
                plt.pause(0.001)

            currentPoint = workingPoints.pop(maxRegretIdx)
            solution.append(currentPoint)

        # final graphics
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(solution[0].getX())
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(solution[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        plt.pause(0.01)

        # interactive graphics mode off
        plt.ioff()

        return solution



if __name__ == '__main__':
    
    instanceName = 'reseau_suisse'
    
    solutionName = instanceName + '_max_regret'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution with the maximum regret heuristic...')

    tsp = TspMaxRegret(instance)
    startPoint = random.randrange(len(solution))
    solution = tsp.generate(startPoint)
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
