Source of TSP instances:

https://www.math.uwaterloo.ca/tsp/index.html
https://www.math.uwaterloo.ca/tsp/data/index.html
