# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with simulated annealing metaheuristic.

@author: beer
"""

import random
import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_simulated_annealing import TspSimulatedAnnealing


if __name__ == '__main__':
    
    instanceName = 'reseau_suisse'
    
    solutionName = instanceName + '_simulated_annealing'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions';

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension

    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a random initial solution...')

    random.shuffle(solution)
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Initial solution for ' + instanceName + ' has length: ' + str(distance))
    print('Refining solution with the simulated annealing metaheuristic...')
    print('', flush=True)

    tsp = TspSimulatedAnnealing(solution)

    #tsp.set_schedule(tsp.auto_new(minutes=3.))
    tsp.set_schedule({'tmax': 5000., 'tmin': 1., 'steps': 150000000, 'updates': 20000})

    solution, distance = tsp.findSolution()

    for i in range(len(solution)):          # rotate id = 0 to beginning
        if solution[i].getId() == 0:
            break
    solution = solution[i:] + solution[:i]  

    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
