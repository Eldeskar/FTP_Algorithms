# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with the greedy nearest insertion heuristic.

@author: beer
"""

import sys
import os

import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from point import Point
from instance import Instance
from helpers import Helpers


class TspGreedyInsertionNearest(object):

    # pass extra data (if any) into the constructor
    def __init__(self, instance):
        self.instance = instance
        self.set_up_graphics()

    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [self.instance.getPoints()[i].getX() for i in range(len(self.instance.getPoints()))]
        y = [self.instance.getPoints()[i].getY() for i in range(len(self.instance.getPoints()))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()

        plt.pause(0.001)
        plt.show()

    def generate(self):
        points = self.instance.getPoints()
        #points.sort(key=lambda x: x.getId())
        
        [firstIdx, nextIndices] = self.findBestInsertPosition(points)
        solution = TspGreedyInsertionNearest.buildTourFromIndices(points, firstIdx, nextIndices)

        return solution


    def	findBestInsertPosition(self, points):
        MAX_GRAPHS = len(points)
        NUM_POINTS_PER_GRAPH = max(1, len(points)//MAX_GRAPHS)    

        centerGravX = sum([points[i].getX() for i in range(len(points))]) / len(points)
        centerGravY = sum([points[i].getY() for i in range(len(points))]) / len(points)
        centerGrav = Point(-1, centerGravX, centerGravY)

        distCenterGrav = sys.float_info.max
        for i in range(len(points)):
            dist = Helpers.euclideanDistance2DPoints(points[i], centerGrav)
            if dist < distCenterGrav:
                distCenterGrav = dist
                firstIdx = i

        nextIndices = [int(firstIdx)]*len(points)  # array with the indices of the next nodes

        # find the best position to insert for each remaining point
        pointsInSolution = [False] * len(points)
        pointsInSolution[firstIdx] = True
 
        for i in range(1, len(points)):
            distCenterGrav = sys.float_info.max
            for ii in range(len(points)):
                if not pointsInSolution[ii]:
                    dist = Helpers.euclideanDistance2DPoints(points[ii], centerGrav)
                    if dist < distCenterGrav:
                        distCenterGrav = dist
                        nearestIdx = ii

            pointsInSolution[nearestIdx] = True

            lowestDistanceIncrease = sys.float_info.max
            lowestDistanceIncreaseIdx = int(-1)
			
            idx = firstIdx
            for j in range(i):
                # compute increase of cost of tour if point farestIdx is inserted between  position idx and idx+1
                distanceIncrease = Helpers.euclideanDistance2DPoints(points[idx], points[nearestIdx]) + Helpers.euclideanDistance2DPoints(points[nearestIdx], points[nextIndices[idx]]) - Helpers.euclideanDistance2DPoints(points[idx], points[nextIndices[idx]])
                if distanceIncrease < lowestDistanceIncrease:
                    lowestDistanceIncrease = distanceIncrease
                    lowestDistanceIncreaseIdx = idx
                    
                idx = nextIndices[idx]
			
            nextIndices[nearestIdx] = nextIndices[lowestDistanceIncreaseIdx]
            nextIndices[lowestDistanceIncreaseIdx] = nearestIdx
            
            # update graphics
            if (i - 2) % NUM_POINTS_PER_GRAPH == 0:
                solution = TspGreedyInsertionNearest.buildPartialTourFromIndices(points, firstIdx, nextIndices)
                x = [solution[i].getX() for i in range(len(solution))]
                x.append(solution[0].getX())
                y = [solution[i].getY() for i in range(len(solution))]
                y.append(solution[0].getY())
                self.line1.set_xdata(x)
                self.line1.set_ydata(y)
                self.figure1.canvas.draw()
                self.figure1.canvas.flush_events()
                plt.pause(0.001)

        # final graphics
        solution = TspGreedyInsertionNearest.buildPartialTourFromIndices(points, firstIdx, nextIndices)
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(solution[0].getX())
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(solution[0].getY())
        self.line1.set_xdata(x)
        self.line1.set_ydata(y)
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        plt.pause(0.01)

        # interactive graphics mode off
        plt.ioff()

        return [firstIdx, nextIndices]
        
 
	
    def buildPartialTourFromIndices(points, firstIdx, nextIndices):
        # walk along next indices to build partial solution
        solution = []
        j = firstIdx
        for i in range(len(points)):
            solution.append(points[j])
            j = nextIndices[j]
            if j == firstIdx:
                break
            
        return solution


    def buildTourFromIndices(points, firstIdx, nextIndices):
        # walk along next indices to build solution
        solution = []
        j = firstIdx
        for i in range(len(points)):
            solution.append(points[j])
            j = nextIndices[j]
            
        return solution


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_greedy_insertion_nearest'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution with the greedy nearest insertion heuristic...')

    tsp = TspGreedyInsertionNearest(instance)
    solution = tsp.generate()
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
