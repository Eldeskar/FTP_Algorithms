# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with ant colony optimization metaheuristic.

@author: beer
"""

import sys
import os
import logging
import random 

import matplotlib.pyplot as plt
import numpy as np

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + '..' + os.path.sep + 'metaheuristics' + os.path.sep + 'antcolony' + os.path.sep))
from antcolony import AntColonyOptimization


class TspAntColonyOptimization(AntColonyOptimization):
    # pass extra data (if any) into the constructor
    def __init__(self, cities):
        self.state = StateTspAntColonyOptimization(cities)
        self.set_up_graphics()
        super(TspAntColonyOptimization, self).__init__(self.state)  # important!


    """
    Ant colony optimization algorithm for finding the shortest route in a 
    travelling salesperson problem instance.

    Parameters:
        m = number of ants
        k_max = number of iterations
        alpha = pheromone importance
        beta = distance importance
        rho = pheromone evaporation rate
        Q = pheromone deposit
        tau = pheromone
        eta = distance
    """


    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting pheromon-trails
        self.figure1, self.ax1 = plt.subplots()
        self.ax1.set_title('Pheromon Trails')
        x = [self.state.cities[i].getX() for i in range(self.state.n)]
        y = [self.state.cities[i].getY() for i in range(self.state.n)]
        self.ax1.plot(x, y, 'b.')
        self.lines = []
        for i in range(self.state.n):
            line = []
            for j in range(self.state.n):
                if i != j:
                    el, = self.ax1.plot([x[i], x[j]], [y[i], y[j]], 'r')
                    line.append(el)
            self.lines.append(line)
            self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()
        
        # graphics for best solution so far
        self.figure2, self.ax2 = plt.subplots()
        self.ax2.set_title('Best Solution')
        self.ax2.plot(x, y, 'b.')
        self.line2, = self.ax2.plot([], [], 'r')
        
        plt.pause(0.001)
        plt.show()


    def update_graphics_1(self):
        # graphics for depicting pheromon-trails
        # update linewidths of graph
        for i in range(self.state.n):
            el_ind = 0
            for j in range(self.state.n):
                if i != j:
                    self.lines[i][el_ind].set_linewidth(self.state.tau[i][j]*(2.5/np.max(self.state.tau)))
                    #self.lines[i][el_ind].set_linewidth(self.state.A[i][j]*(10./np.max(self.state.A)))
                    el_ind +=1
        self.figure1.canvas.draw()
        self.figure1.canvas.flush_events()


    def update_graphics_2(self, solution):
        # graphics for depicting of best solution
        x = [solution[i].getX() for i in range(len(solution))]
        x.append(x[0])
        y = [solution[i].getY() for i in range(len(solution))]
        y.append(y[0])
        self.line2.set_xdata(x)
        self.line2.set_ydata(y)
        self.figure2.canvas.draw()
        self.figure2.canvas.flush_events()
        

    def ant_walk(self, best_solution, best_energy):
        sol = [random.randrange(self.state.n)]  # Start at first node
        while len(sol) < self.state.n:
            i = sol[-1]
            neighbors = [j for j in range(self.state.n) if j not in sol]
            if len(neighbors) == 0:
                raise IndexError("Something is wrong with instance structure")
            p = [self.state.A[(i, j)] for j in neighbors]
            sampled_neighbor = random.choices(neighbors, weights=p)[0]
            sol.append(sampled_neighbor)
        sol.append(sol[0])
        
        energy = self.energy(sol)
        
        self.state.update_R(sol, energy, self.Q)
            
        if energy < best_energy:
            logging.info("Better ACO solution found. Score: %.2f", energy)
            best_solution = [self.state.cities[j] for j in sol[:-1]]
            best_energy = energy
            self.update_graphics_2(best_solution)
            
        return best_solution, best_energy


    def special_action(self):
        self.update_graphics_1()
        

    def init_best_solution(self):
        return []    # solution is a list of cities indices


    def energy(self, sol):
        E = 0
        for i in range(len(sol) - 1):
            E += self.state.distance_matrix[sol[i]][sol[i + 1]]
        return E


class StateTspAntColonyOptimization(object):
    """ data structure for TspAntColonyOptimization """
    def __init__(self, cities):
        self.cities = cities
        self.n = len(cities)

        self.distance_matrix = np.zeros([self.n, self.n])
        for i in range(self.n):
            for j in range(self.n):
                if i != j:
                    self.distance_matrix[i,j] = Helpers.euclideanDistance2DPoints(cities[i], cities[j])

        self.tau = 1.*np.ones([self.n, self.n])        # pheromone matrix (nxn-array numpy)
        self.eta = 1/(self.distance_matrix + 1e-12)     # inverse distances matrix (nxn-array numpy)
        self.R = np.zeros([self.n, self.n])             # pheromone reinforcement matrix (nxn-array numpy)
        self.A = np.zeros([self.n, self.n])             # edge attractivness matrix (nxn-array numpy)

        
    def init_R(self):
        self.R = np.zeros([self.n, self.n])             

        
    def update_R(self, solution, energy, Q):
        for i in range(0, self.n + 1):
            self.R[(solution[i-1], solution[i])] += Q / energy
            

if __name__ == '__main__':
    
    instanceName = 'berlin52'
    
    solutionName = instanceName + '_ant_colony_opt'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    cities = instance.getPoints()
    random.shuffle(cities)
    print('Instance has ' + str(len(cities)) + ' points.')

    print('Generating a solution with the ant colony optimization heuristic...')

    tsp = TspAntColonyOptimization(cities[:])

    #tsp.set_schedule(tsp.auto_new(minutes=3.))
    tsp.set_schedule({'alpha': 1.4, 'beta': 1.8, 'rho': 0.4, 'Q': 2., 'ants': 200, 'steps': 75})

    solution, distance = tsp.ant_colony_optimization()
        
    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
