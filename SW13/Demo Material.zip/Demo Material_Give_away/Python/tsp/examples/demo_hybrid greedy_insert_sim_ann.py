# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with simulated annealing metaheuristic.

@author: beer
"""

import sys
import os
from pathlib import Path

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_simulated_annealing import TspSimulatedAnnealing
from tsp_greedy_insertion_random import TspGreedyInsertionRandom




if __name__ == '__main__':
    
    instanceName = 'berlin52'
    
    solutionName = instanceName + '_greedy_simulated_annealing'
    saveStateName = instanceName + '_save_state'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'
    pathToSaveStates = 'TSP_Savestates'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'
    saveStateFilenameExtension = '.sas'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension
    pathToSaveState = pathToSaveStates + os.path.sep + saveStateName + saveStateFilenameExtension

    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    tsp = TspSimulatedAnnealing(solution)

    found_saved_state = True
    print('Trying to load saved state...')
    try:
        solution = tsp.load_state(pathToSaveState)
        print('Saved state succesfully loaded!')
    except OSError:
        print('No saved state found. Generating an initial solution with greedy insertion heuristic...')
        solution = TspGreedyInsertionRandom.generate(instance)
        tsp.set_state(solution)
        try:
            path = Path(pathToSaveState)
            os.makedirs(path.parent.absolute())
        except OSError:
            pass
        tsp.save_state(pathToSaveState)
        pass
            
    distance = Helpers.euclideanDistance2DList(solution)
    print('Initial solution for ' + instanceName + ' has length: ' + str(distance))
    print('Refining solution with the simulated annealing metaheuristic...')
    print('', flush=True)
 
    #tsp.set_schedule(tsp.auto_new(minutes=3.))
    tsp.set_schedule({'tmax': 50., 'tmin': 0.1, 'steps': 1000000, 'updates': 500})

    solution, distance = tsp.findSolution()

    for i in range(len(solution)):          # rotate id = 0 to beginning
        if solution[i].getId() == 0:
            break
    solution = solution[i:] + solution[:i]  

    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
