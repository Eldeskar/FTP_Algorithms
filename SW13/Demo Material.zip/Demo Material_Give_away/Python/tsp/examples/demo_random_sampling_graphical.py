# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated as a random sampling.

@author: beer
"""

import sys
import os
import random

import matplotlib.pyplot as plt

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

#sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
#from tsp_random_sampling import TspRandomSampling

class TspRandomSampling(object):

    # pass extra data (if any) into the constructor
    def __init__(self, instance):
        self.instance = instance
        self.set_up_graphics()

    def set_up_graphics(self):
        # interactive graphics mode on
        plt.ion()

        # graphics for depicting of solution
        self.figure1, self.ax1 = plt.subplots()
        x = [self.instance.getPoints()[i].getX() for i in range(len(self.instance.getPoints()))]
        y = [self.instance.getPoints()[i].getY() for i in range(len(self.instance.getPoints()))]
        self.ax1.plot(x, y, 'b.')
        self.line1, = self.ax1.plot([], [], 'r')

        plt.pause(0.001)
        plt.show()

    def generate(self, numTries):
        MAX_GRAPHS = 100
        NUM_TRIES_PER_GRAPH = max(1, numTries//MAX_GRAPHS)    

        solution = self.instance.clonePointList()
        bestDistance = sys.float_info.max

        for i in range(numTries):
            random.shuffle(solution)

            if i % NUM_TRIES_PER_GRAPH == 0:
                # update graphics
                x = [solution[i].getX() for i in range(len(solution))]
                x.append(solution[0].getX())
                y = [solution[i].getY() for i in range(len(solution))]
                y.append(solution[0].getY())
                self.line1.set_xdata(x)
                self.line1.set_ydata(y)
                self.figure1.canvas.draw()
                self.figure1.canvas.flush_events()
                plt.pause(0.001)

            distance = Helpers.euclideanDistance2DList(solution)

            if distance < bestDistance:
                bestSolution = solution.copy()
                bestDistance = distance

            # interactive graphics mode off
            plt.ioff()
        return bestSolution



if __name__ == '__main__':

    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_rand_sampling'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    solution = instance.getPoints()
    print('Instance has ' + str(len(solution)) + ' points.')

    print('Generating a solution by random sampling...')
		
    NUM_TRIES = 1000
    tsp = TspRandomSampling(instance)
    solution = tsp.generate(NUM_TRIES)
    distance = Helpers.euclideanDistance2DList(solution)
        
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
