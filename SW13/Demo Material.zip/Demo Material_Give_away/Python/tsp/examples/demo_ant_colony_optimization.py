# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with ant colony optimization metaheuristic.

@author: beer
"""

import sys
import os
import random

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from printer import Printer
from instance import Instance
from helpers import Helpers

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from tsp_ant_colony import TspAntColonyOptimization


if __name__ == '__main__':
    
    instanceName = 'tsp225'
    
    solutionName = instanceName + '_ant_colony_opt'
    pathToInstances = 'TSP_Instances'
    pathToSolutions = 'TSP_Solutions'

    instanceFilenameExtension = '.tsp'
    solutionFilenameExtension = '.html'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension


    print('Loading instance ' + instanceName + '...')
    instance = Instance(pathToInstance)

    cities = instance.getPoints()
    print('Instance has ' + str(len(cities)) + ' points.')

    print('Generating a solution with the ant colony optimization heuristic...')

    random.shuffle(cities)
    tsp = TspAntColonyOptimization(cities)
    
    #tsp.set_schedule(tsp.auto_new(minutes=3.))
    tsp.set_schedule({'alpha': 1., 'beta': 2., 'rho': 0.4, 'Q': 2., 'ants': 1000, 'steps': 100})

    solution, distance = tsp.ant_colony_optimization()
        
    print('')
    print('', flush=True)
    print('Solution for ' + instanceName + ' has length: ' + str(distance))
    print('')

    # generate visualization of result, will be stored in directory pathToSolutions
    Printer.writeToSVG(instance, solution, pathToSolution)
