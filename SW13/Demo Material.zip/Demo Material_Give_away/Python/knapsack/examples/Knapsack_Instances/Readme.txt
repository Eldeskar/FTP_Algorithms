Instance data must be of the following form (text-file):

	Number of items
	Capacity of knapsack

	Weight of items (one per line)

	Value of items (one per line)



Internet source for "KS_large_1" and "KS_large_3" and many more (in subfolder raw - they have to be converted first!):
http://artemisa.unicauca.edu.co/~johnyortega/instances_01_KP/


Best result for "KS_large_1": 563647
Best result for "KS_large_3": 146919