# -*- coding: utf-8 -*-
"""
Created on Mon Sep 27 21:00:21 2021

Demo for TSP solutions generated with simulated annealing metaheuristic.

@author: beer
"""

import sys
import os

sys.path.append(os.path.realpath('..' + os.path.sep + 'utils' + os.path.sep))
from instance import Instance

sys.path.append(os.path.realpath('..' + os.path.sep + 'heuristics' + os.path.sep))
from knapsack_simulated_annealing import KnapsackSimulatedAnnealing


if __name__ == '__main__':
    
    instanceName = 'KS_large_1'
    
    solutionName = instanceName + '_simulated_annealing'
    pathToInstances = 'Knapsack_Instances'
    pathToSolutions = 'Knapsack_Solutions'

    instanceFilenameExtension = '.txt'
    solutionFilenameExtension = '.txt'

    pathToInstance = pathToInstances + os.path.sep + instanceName + instanceFilenameExtension
    pathToSolution = pathToSolutions + os.path.sep + solutionName + solutionFilenameExtension

    print('Loading instance ' + instanceName + ' ...')
    instance = Instance(pathToInstance)

    print('Instance has ' + str(instance.getNumItems()) + ' items.')

    print('Computing solution with the simulated annealing metaheuristic ...')
    print('', flush=True)

    ks = KnapsackSimulatedAnnealing(instance)

    ks.copy_strategy = "method"     # deepcopy is very slow!

    #ks.set_schedule(ks.auto(minutes=3.))
    ks.set_schedule({'tmax': 5000., 'tmin': 50., 'steps': 1000000, 'updates': 100})

    solution, bestNegVal = ks.findSolution()

    print('')
    print('', flush=True)
    print('Knapsack has capacity: ' + str(solution.getCapacity()))
    print('Solution has weight: ' + str(solution.getWeight()))
    print('Solution has value: ' + str(solution.getValue()))
    flags = []
    for k in range(solution.getNumItems()):
        if solution.getItemFlag(k):
            flags.append(1)
        else:
            flags.append(0)
    print('Item flags: ' + str(flags))
    print('')
